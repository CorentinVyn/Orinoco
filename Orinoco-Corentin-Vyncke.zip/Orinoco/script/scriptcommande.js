window.addEventListener("DOMContentLoaded", () => {
    const orderData = localStorage.getItem("orderData");
    if (!orderData) {
        console.error("Aucune donnée de commande trouvée !");
        return;
    }

    const order = JSON.parse(orderData);

    //Affiche le titulaire de la commande
    const contact = order.contact;
    document.getElementById("contact-name").textContent = `${contact.firstName} ${contact.lastName}`;

    //Affiche l'order_id
    document.getElementById("order-id").textContent = order.orderId;
});
