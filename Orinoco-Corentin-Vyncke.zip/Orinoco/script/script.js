const api = "http://localhost:3000";

let paniertot = [];
let Nbrearticlepanier = 0;
    localStorage.removeItem("panier");

const panierElement = document.getElementById("nombre-article");

// Chargement du panier depuis le localStorage
const panierLocal = localStorage.getItem("panier");
if (panierLocal) {
    paniertot = JSON.parse(panierLocal);
    Nbrearticlepanier = paniertot.length;

}

async function affichageours(container) {
    const res = await fetch(`${api}/api/teddies`);
    const oursList = await res.json();

    // Boucle pour afficher tous les ours de l'api
    oursList.forEach(ours => {

        //Intégration des chaque ours dans le html
        const div = document.createElement("div");
        div.classList.add("carte");
        div.dataset.id = ours._id;

        const img = document.createElement("img");
        img.src = ours.imageUrl;
        img.alt = `Image de ${ours.name}`;
        img.classList.add("img");

        const infos = document.createElement("div");
        infos.classList.add("infos");

        infos.innerHTML = `
            <h2>${ours.name}</h2>
            <p>Prix : ${ours.price / 100} €</p>
            <p>${ours.description}</p>
        `;

        div.appendChild(img);
        div.appendChild(infos);


        //Ouvrir la fenêtre modale en reprenant les mêmes informations 
        div.addEventListener("click", async () => {
            const id = div.dataset.id;
            const res = await fetch(`${api}/api/teddies/${id}`);
            const oursDetail = await res.json();

            const modal = document.getElementById("modal");
            const modalBody = document.getElementById("modal-body");
            const select = document.getElementById("select-option");
            const positionModul = document.getElementById("position-modul");

            if (!modal || !modalBody || !select || !positionModul) return;

            modal.dataset.id = oursDetail._id;
            modalBody.innerHTML = "";

            const detailDiv = document.createElement("div");
            detailDiv.classList.add("zoom");

            const detailImg = document.createElement("img");
            detailImg.src = oursDetail.imageUrl;
            detailImg.alt = `Image de ${oursDetail.name}`;
            detailImg.classList.add("img");

            const detailInfos = document.createElement("div");
            detailInfos.classList.add("infos");

            detailInfos.innerHTML = `
                <h2>${oursDetail.name}</h2>
                <p>Prix : ${oursDetail.price / 100} €</p>
                <p>${oursDetail.description}</p>
            `;

            //Parcours de tous les options possibles de chaque nounours
            select.innerHTML = '<option selected disabled>Veuillez choisir la modulation</option>';
            oursDetail.colors.forEach(color => {
                const option = document.createElement("option");
                option.value = color;
                option.textContent = color;
                select.appendChild(option);
            });

            positionModul.style.display = "block";

            detailDiv.appendChild(detailImg);
            detailDiv.appendChild(detailInfos);
            modalBody.appendChild(detailDiv);
            modal.style.display = "block";
        });

        container.appendChild(div);
    });
}

//Fonction qui affiche le contenu du panier en cliquant sur l'icon panier
async function affichagepanier(container) {

    //Boucle pour parcourir tous les articles du panier
    for (const article of paniertot) {
        const id = article.id;
        let produit = null;

        try {
            let res = await fetch(`${api}/api/teddies/${id}`);
            if (res.ok) {
                produit = await res.json();
            }

            if (produit) {
                affichageProduit(produit, container); 
            } 
        } catch (error) {
            console.error("Erreur lors du chargement d'un article :", error);
        }
    }
}


//Fonction qui ajoute l'article au panier en cliquant sur le bouton ajouter
document.getElementById("ajouter")?.addEventListener("click", (event) => {
    event.preventDefault();

    const select = document.getElementById("select-option");
    const choix = select?.value;

    //Obligation de mettre une option pour l'article
    if (!choix || select.selectedIndex === 0) {
        alert("Veuillez sélectionner une modulation avant d'ajouter au panier.");
        return;
    }

    const modal = document.getElementById("modal");
    const articleId = modal?.dataset?.id;

    paniertot.push({ id: articleId, option: choix });
    localStorage.setItem("panier", JSON.stringify(paniertot));

    Nbrearticlepanier = paniertot.length;
    if (panierElement) panierElement.innerHTML = Nbrearticlepanier;
    alert("Article ajouté au panier !");
});


//Evenement pour fermer la fenetre modal
document.getElementById("modal-close")?.addEventListener("click", () => {
    const modal = document.getElementById("modal");
    if (modal) modal.style.display = "none";
});

window.addEventListener("click", (event) => {
    const modal = document.getElementById("modal");
    if (event.target === modal) {
        modal.style.display = "none";
    }
});


//Affichage dans le panier
window.addEventListener("DOMContentLoaded", () => {
    if (panierElement) panierElement.innerHTML = paniertot.length;

    const container = document.getElementById("contenu");
    if (container) {
        if (window.location.pathname.endsWith("panier.html")) {
            affichagepanier(container);
        } else {
            affichageours(container);
        }
    }
});
