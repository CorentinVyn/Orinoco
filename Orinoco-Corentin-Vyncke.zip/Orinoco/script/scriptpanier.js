const api = "http://localhost:3000";

let Nbrearticlepanier = 0;
let paniertot = [];
let montantpanier = 0;
const panierLocal = localStorage.getItem("panier");

//Affichage du nombre d'article au niveau du logo du caddie
if (panierLocal) {
    paniertot = JSON.parse(panierLocal);
    Nbrearticlepanier = paniertot.length;

    const panier = document.getElementById("nombre-article");
    if (panier) panier.innerHTML = Nbrearticlepanier;
}

//Fonction pour afficher le panier
async function affichagepanier(container) {
    const paniertot = JSON.parse(localStorage.getItem("panier")) || [];

    //Le cas où le panier est vide
    if (paniertot.length === 0) {
        container.innerHTML = "<p>Votre panier est vide.</p>";
        return;
    }

    //Parcourir les articles qui sont dans le panier
    for (const article of paniertot) {
        const id = article.id;

        try {
            let data = null;
                const res = await fetch(`${api}/api/teddies/${id}`);
                if (res.ok) {
                    data = await res.json();
            }

            //Afficher les produits du panier
            affichageProduit(data, container, article.option);
        } catch (error) {
            console.error(`Erreur lors du chargement de l'article ${id} :`, error);
        }
    }
}


//Fonction qui affiche un produit dans le panier
function affichageProduit(data, container, option) {
    const div = document.createElement("div");
    div.classList.add("carte");

    const img = document.createElement("img");
    img.src = data.imageUrl;
    img.alt = `Image de ${data.name}`;
    img.classList.add("img");

    const infos = document.createElement("div");
    infos.classList.add("infos");

    const name = document.createElement("h2");
    name.textContent = data.name;

    const price = document.createElement("p");
    price.textContent = `Prix : ${data.price / 100} €`;

    const montant=document.getElementById("montant");
    montantpanier += data.price / 100;
    montant.innerHTML = montantpanier;


    const description = document.createElement("p");
    description.textContent = data.description;

    const opt = document.createElement("p");
    opt.textContent = `Option choisie : ${option}`;

    infos.appendChild(name);
    infos.appendChild(price);
    infos.appendChild(opt);
    infos.appendChild(description);

    div.appendChild(img);
    div.appendChild(infos);
    container.appendChild(div);
}


//Executer la fonction affichage panier
document.addEventListener("DOMContentLoaded", () => {
    const container = document.querySelector(".carte");
    affichagepanier(container);
});




//Fonctions pour vérifier que le formulaire comporte des informations correctes
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}


function validateOrderData(contact, products) {
    const errors = [];
    if (!contact.firstName || typeof contact.firstName !== 'string') errors.push("Prénom manquant");
    if (!contact.lastName || typeof contact.lastName !== 'string') errors.push("Nom manquant");
    if (!contact.address || typeof contact.address !== 'string') errors.push("Adresse manquante");
    if (!contact.city || typeof contact.city !== 'string') errors.push("Ville manquante");
    if (!contact.email || typeof contact.email !== 'string' || !isValidEmail(contact.email)) errors.push("Email invalide");

    if (!Array.isArray(products) || products.length === 0 || !products.every(p => typeof p === 'string')) {
        errors.push("Produits invalides");
    }

    return errors;
}


async function sendOrder(contact, products) {

    //Affichage des erreurs si le formulaire est incorrect
    const errors = validateOrderData(contact, products);
    if (errors.length > 0) {
        alert("Erreur de validation :\n" + errors.join("\n"));
        return;
    }

    if (products.length === 0) {
        alert("Aucun produit dans le panier !");
        return;
    }

    try {
        const response = await fetch(`${api}/api/teddies/order`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ contact, products })
        });
        const data = await response.json();
        console.log("Commande réussie :", data);

        const orderId = data.orderId;
        if (orderId) {
            alert(`Commande envoyée avec succès ! ID : ${orderId}`);
localStorage.setItem("orderData", JSON.stringify(data));

//Redirection vers la page qui indique que la commande est validée
window.location.href = `commande.html`;
} 

    } catch (error) {
        console.error("Erreur lors de l'envoi de la commande :", error);
        alert("Une erreur est survenue, veuillez réessayer.");
    }
}


//Récupération des informations en validant le formulaire
document.getElementById('validation').addEventListener('click', () => {
    const contact = {
        firstName: document.getElementById('firstName').value.trim(),
        lastName: document.getElementById('lastName').value.trim(),
        address: document.getElementById('address').value.trim(),
        city: document.getElementById('city').value.trim(),
        email: document.getElementById('email').value.trim(),
    };

    const panier = JSON.parse(localStorage.getItem('panier')) || [];
    const products = panier.map(article => article.id);

    sendOrder(contact, products);
});

